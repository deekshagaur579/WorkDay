﻿using System;
using System.Collections.Generic;
using WorkDayApplication.DataAccess;
using WorkDayApplication.Models;
using WorkDayApplication.Utilities;

namespace WorkDayApplication.ViewModels
{
    //Factory
    public class LeaveTypeViewModel
    {
        public void ApplyLeave(LeaveFactory factory, Leave leave)
        {
            LeaveTypeClass l = factory.CreateLeave(leave);
            l.Apply();
        }
    }

}
