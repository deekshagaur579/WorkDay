﻿using System;
using WorkDayApplication.DataAccess;
using WorkDayApplication.Utilities;

namespace WorkDayApplication.Models
{
 public class Mail
    {
        public int Id { get; set; }
        public string UserId { get; set; }
        public string MailType { get; set; }
        public string MailSubject { get; set; }
        public DateTime SentDate { get; set; }

    }

}