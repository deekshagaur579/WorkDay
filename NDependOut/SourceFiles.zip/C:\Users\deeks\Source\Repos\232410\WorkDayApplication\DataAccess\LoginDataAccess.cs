﻿using WorkDayApplication.Utilities;

namespace WorkDayApplication.DataAccess
{
    public class LoginDataAccess
    {
        public string ValidatePassword(string CoUserID) {
            string query = "Select CoLoginPassword from TaLogin where CoUserID = " + CoUserID;
            string dbPassword = DataAccessUtility.GetData(query).ToString();
            return dbPassword;
        }
    }
}
