﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using WorkDayApplication.Interfaces;
using WorkDayApplication.Models;
using WorkDayApplication.ViewModels;

namespace WorkDayApplication.Controllers
{
    public class AttendanceController : Controller
    {
        // GET: AttendanceController
        public ActionResult AttendanceDetails()
        {
            string UserId = HttpContext.Session.GetString("UserId");
            AttendanceViewModel obj = new AttendanceViewModel();
            List<Attendance> listData = new List<Attendance>();
            //listData = obj.GetAttendanceDetails(UserId);

            // Creating the base attendance object
            IAttendance basicAttendance = new AttendanceViewModel();
            // Adding decorators
            //IAttendance Attendance = new AttendanceDecorator(basicAttendance);
            IAttendance holidayAttendance =
                new HolidayListDecorator(basicAttendance,  obj.GetAttendance(UserId) );
            listData = holidayAttendance.GetAttendance(UserId);
            return View(listData);

        }
    }

}
