﻿using System.Collections.Generic;
using WorkDayApplication.Models;

namespace WorkDayApplication.Interfaces
{
    public interface IAttendance
    {
        List<Attendance> GetAttendance(string employeeId);
    }
}
