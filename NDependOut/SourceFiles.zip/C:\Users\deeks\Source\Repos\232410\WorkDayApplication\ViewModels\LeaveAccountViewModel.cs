﻿using System;
using System.Collections.Generic;
using WorkDayApplication.DataAccess;
using WorkDayApplication.Models;

namespace WorkDayApplication.ViewModels
{
    public class LeaveAccountViewModel
    {
        public List<LeaveAccount> GetLeaveAccount(string CoUserID)
        {
            LeaveDataAccess LDA = new LeaveDataAccess();
            return LDA.GetLeaveAccount(CoUserID);
        }
        public LeaveAccount GetLeaveAccountById(int CoLeaveId)
        {
            LeaveDataAccess LDA = new LeaveDataAccess();
            return LDA.GetLeaveAccountById(CoLeaveId);
        }
    }
}
