﻿namespace WorkDayApplication.Interfaces
{
    public interface IMailObserver
    {
        void UpdateMail(ILeaveSubject leave);
        //void SendMail(ILeaveSubject leave);
    }
}
