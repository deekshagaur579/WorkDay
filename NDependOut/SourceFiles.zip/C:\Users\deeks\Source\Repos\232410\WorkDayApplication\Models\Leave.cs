﻿using System;
using System.Collections.Generic;
using System.Net.NetworkInformation;
using WorkDayApplication.DataAccess;
using WorkDayApplication.Interfaces;
using WorkDayApplication.Utilities;
using WorkDayApplication.ViewModels;

namespace WorkDayApplication.Models
{

    public class Leave: ILeaveSubject
    {
        public Leave()
        {
            Reason = "Clicked Apply Leave";
        }
        public int Id { get; set; }
        public int? LeaveAccountId { get; set; }
        public string UserId { get; set; }
        public DateTime? Startdate { get; set; }
        public Nullable<System.DateTime> EndDate { get; set; }
        public Nullable<System.DateTime> Applydate { get; set; }
        public LeaveAccount leaveAccount { 
            get { LeaveAccountViewModel ac = new LeaveAccountViewModel();
                return ac.GetLeaveAccountById(this.Id); } 
            set { } 
        }
        public string Reason
        {
            get;set;
        }

        //ObserverPattern
        private LeaveStatus? _leaveStatus;
        public LeaveStatus? Status
        {
            get { return _leaveStatus; }
            set { _leaveStatus = value; }
        }

        private List<IMailObserver> _observers = new List<IMailObserver>();

        //ObserverPattern
        public void Attach(IMailObserver observer)
        {
            _observers.Add(observer);
        }
        public void Notify()
        {
            foreach (var observer in _observers)
            {
                observer.UpdateMail(this);
                //observer.SendMail(this);
            }
        }

        public void MailMethod()
        {
            this.Notify();
        }

    }

}


