﻿using System.Net.NetworkInformation;
using System;

namespace WorkDayApplication.Models
{
    // Product: Leave : Factory Method
    public abstract class LeaveTypeClass
    {
        public string LeaveType { get; }
        public Leave leave { get; }

        protected LeaveTypeClass(string leaveType, Leave leave)
        {
            LeaveType = leaveType;
            leave = leave;
        }

        public abstract void Apply();
    }

    // Concrete products: PaidLeave and UnpaidLeave
    public class PaidLeave : LeaveTypeClass
    {
        public PaidLeave(Leave leave) : base("Paid", leave) { }

        public override void Apply()
        {
            //Console.WriteLine($"Applying Paid Leave for {DurationInDays} days.");
            // Additional logic for applying paid leave...
        }
    }

    public class UnpaidLeave : LeaveTypeClass
    {
        public UnpaidLeave(Leave leave) : base("Unpaid", leave) { }

        public override void Apply()
        {
            //Console.WriteLine($"Applying Unpaid Leave for {DurationInDays} days.");
            // Additional logic for applying unpaid leave...
        }
    }

    // Creator: LeaveFactory
    public abstract class LeaveFactory
    {
        public abstract LeaveTypeClass CreateLeave(Leave Leave);
    }

    // Concrete creators: PaidLeaveFactory and UnpaidLeaveFactory
    public class PaidLeaveFactory : LeaveFactory
    {
        public override LeaveTypeClass CreateLeave(Leave Leave)
        {
            return new PaidLeave(Leave);
        }
    }

    public class UnpaidLeaveFactory : LeaveFactory
    {
        public override LeaveTypeClass CreateLeave(Leave Leave)
        {
            return new UnpaidLeave(Leave);
        }
    }

}
