﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WorkDayApplication.Models;
using WorkDayApplication.ViewModels;

namespace WorkDayApplication.Controllers
{
    public class LeaveController : Controller
    {
        public ActionResult LeaveAccount()
        {
            LeaveAccountViewModel leaveacc = new LeaveAccountViewModel();
            string UserId = HttpContext.Session.GetString("UserId");
            return View(leaveacc.GetLeaveAccount(UserId));
        }

        [HttpPost]
        public ActionResult ApplyLeave([FromBody]Leave leave)
        {
            LeaveTypeViewModel ltVM = new LeaveTypeViewModel();

            // Apply a Paid Leave
            var paidLeaveFactory = new PaidLeaveFactory();
            ltVM.ApplyLeave(paidLeaveFactory, leave);

            // Apply an Unpaid Leave
            var unpaidLeaveFactory = new UnpaidLeaveFactory();
            ltVM.ApplyLeave(unpaidLeaveFactory, leave);
            //ApplyLeave();
            //observer
            var observerApplied = new ConcreteObserver();
            leave.Attach(observerApplied);
            leave.Status = Utilities.LeaveStatus.Applied;
            leave.MailMethod();
            return RedirectToAction("LeaveAccount");
        }
        [HttpPost]
        public ActionResult CancelLeave([FromBody]Leave leave)
        {
            var observerCancelled = new ConcreteObserver();
            leave.Attach(observerCancelled);
            leave.Status = Utilities.LeaveStatus.Cancelled;
            leave.MailMethod();
            return RedirectToAction("LeaveAccount");
        }
        [HttpPost]
        public ActionResult ApproveLeave([FromBody]Leave leave)
        {
            var observerAprooved = new ConcreteObserver();
            leave.Attach(observerAprooved);
            leave.Status = Utilities.LeaveStatus.Aprooved;
            leave.MailMethod();
            return RedirectToAction("LeaveAccount");
        }

       
    }
}
