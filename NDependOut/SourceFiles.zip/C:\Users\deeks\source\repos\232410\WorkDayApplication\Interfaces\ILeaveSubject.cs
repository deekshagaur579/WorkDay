﻿using WorkDayApplication.ViewModels;

namespace WorkDayApplication.Interfaces
{
    public interface ILeaveSubject
    {
        void Attach(IMailObserver observer);
        void Notify();
    }
}
