﻿using System;
using System.Collections.Generic;
using WorkDayApplication.DataAccess;
using WorkDayApplication.Utilities;

namespace WorkDayApplication.Models
{
    public class Employee
    {
        public int id { get; set; }
        public string  UserID { get; set; }
        public string  FirstName { get; set; }
        public string  LastName { get; set; }
        public string  Created { get; set; }
        public string  Updated { get; set; }
        public UserRole  Role { get; set; }
        public string  AddressLine1 { get; set; }
        public string  AddressLine2 { get; set; }
        public string  AddressLine3 { get; set; }
        public string  Designation { get; set; }
        public string  Department { get; set; }
        public Boolean  Active { get; set; }
        public List<Employee> GetEmployeeList()
        {
            UserDataAccess EDA = new UserDataAccess();
            return EDA.GetEmployeeList();
        }

        public void ChangeStatus(int id, bool newValue)
        {
            UserDataAccess EDA = new UserDataAccess();
            EDA.ChangeEmployeeStatus(id, newValue);
        }

        public Employee GetEmployeeDetails(string userID)
        {
            UserDataAccess EDA = new UserDataAccess();
            return EDA.GetEmployeeDetails(userID);
        }
    }
}
