﻿using System;
using WorkDayApplication.Models;
using WorkDayApplication.Utilities;

namespace WorkDayApplication.Interfaces
{
    // Builder Interface
    public interface IUserBuilder
    {
        void SetId(int id);
        void SetUserID(string userID);
        void SetFirstName(string firstName);
        void SetLastName(string lastName);
        void SetCreated(DateTime created);
        void SetUpdated(DateTime updated);
        void SetRole(UserRole role);
        void SetAddress(string addressLine1, string addressLine2, string addressLine3);
        void SetDesignation(string designation);
        void SetDepartment(string department);
       // void SetActive(Boolean active);
        User Build();
    }
}
