﻿using System;
using System.Collections.Generic;
using WorkDayApplication.DataAccess;
using WorkDayApplication.Interfaces;
using WorkDayApplication.Models;
using WorkDayApplication.Utilities;

namespace WorkDayApplication.ViewModels
{
    public class HolidayViewModel
    {
        public List<Holiday> GetHolidayList()
        {
            HolidayDataAccess ADA = new HolidayDataAccess();
            return ADA.GetHolidayList();
        }
    }

    class HolidayListDecorator : AttendanceDecorator
    {
        private List<Attendance> _holidays;

        public HolidayListDecorator(IAttendance attendance, List<Attendance> holidays) : base(attendance)
        {
            _holidays = holidays;
        }

        public override List<Attendance> GetAttendance(string employeeId)
        {
            foreach (var x in _holidays)
            {
                if (string.IsNullOrEmpty(x.AttendanceType))
                {
                    x.UserID = employeeId;
                    x.Created = x.Created;
                    x.Updated = x.Updated;
                    x.AttendanceType = "Holiday";
                }
            }

            return _holidays;
        }
    }
}

