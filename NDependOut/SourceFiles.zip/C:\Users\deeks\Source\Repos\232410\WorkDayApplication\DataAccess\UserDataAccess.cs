﻿using System;
using System.Collections.Generic;
using System.Data;
using WorkDayApplication.Models;
using WorkDayApplication.Utilities;

namespace WorkDayApplication.DataAccess
{
    public class UserDataAccess
    {
        public List<User> GetEmployeeList()
        {
            string query = "Select CoId,CoUserID,CoFirstName,CoLastName,CoCreated,CoUpdated,CoRole,CoAddressLine1,CoAddressLine2,CoAddressLine3,CoDesignation,CoDepartment,CoActive from TaEmployee ";
            DataTable dt = DataAccessUtility.ExecuteQuery(query);
            List<User> list = new List<User>();
            foreach (DataRow dr in dt.Rows)
            {
                list.Add(new User()
                {
                    id = Convert.ToInt32(dr["CoId"]),
                    UserID = dr["CoUserID"].ToString(),
                    FirstName = dr["CoFirstName"].ToString(),
                    LastName = dr["CoLastName"].ToString(),
                    AddressLine1 = dr["CoAddressLine1"].ToString(),
                    AddressLine2 = dr["CoAddressLine2"].ToString(),
                    AddressLine3 = dr["CoAddressLine3"].ToString(),
                    Department = dr["CoDepartment"].ToString(),
                    Designation = dr["CoDesignation"].ToString(),
                    Role = (UserRole)Enum.Parse(typeof(UserRole), dr["CoRole"].ToString(),true),
                    Active = Convert.ToBoolean(dr["CoActive"].ToString())
                });
            }
            return list;
        }

        public void ChangeEmployeeStatus(int id, bool newValue)
        {
            string query = "Update TaEmployee set CoActive =" + Convert.ToInt32(newValue) + " where CoId = " + id;
            DataAccessUtility.Update(query);
        }

        public User GetEmployeeDetails(string userID)
        {
            string query = "Select CoId,CoUserID,CoFirstName,CoLastName,CoCreated,CoUpdated,CoRole,CoAddressLine1,CoAddressLine2,CoAddressLine3,CoDesignation,CoDepartment,CoActive from TaEmployee ";
            DataRow dr = DataAccessUtility.ExecuteQuery(query).Rows[0];
            User emp = new User();
            emp.id = Convert.ToInt32(dr["CoId"]);
            emp.UserID = dr["CoUserID"].ToString();
            emp.FirstName = dr["CoFirstName"].ToString();
            emp.LastName = dr["CoLastName"].ToString();
            emp.AddressLine1 = dr["CoAddressLine1"].ToString();
            emp.AddressLine2 = dr["CoAddressLine2"].ToString();
            emp.AddressLine3 = dr["CoAddressLine3"].ToString();
            emp.Department = dr["CoDepartment"].ToString();
            emp.Designation = dr["CoDesignation"].ToString();
            emp.Role = (UserRole)Enum.Parse(typeof(UserRole), dr["CoRole"].ToString(), true);
            emp.Active = Convert.ToBoolean(dr["CoActive"].ToString());
            return emp;
        }
    }
}
