﻿using System;
using WorkDayApplication.DataAccess;
using WorkDayApplication.Interfaces;
using WorkDayApplication.Models;
using WorkDayApplication.Utilities;

namespace WorkDayApplication.ViewModels
{
   class ConcreteObserver : IMailObserver
    {
        public void UpdateMail(ILeaveSubject leave)
        {
            LeaveDataAccess LDA = new LeaveDataAccess();
            LDA.SaveLeave((leave as Leave));
            LDA.UpdateLeaves((leave as Leave));
            //DataAccessUtility.SendMail("Leave Applied", "<h1>Leave Applied</h1>");
        }
    }

}