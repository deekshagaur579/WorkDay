﻿using System;
using System.Collections.Generic;
using System.Data;
using WorkDayApplication.Models;
using WorkDayApplication.Utilities;

namespace WorkDayApplication.DataAccess
{
    public class HolidayDataAccess
    {
        public List<Holiday> GetHolidayList()
        {
            string query = "Select CoId,CoCreated,CoUpdated,CoDate,CoReason from TaHolidayList";
            DataTable dt = DataAccessUtility.ExecuteQuery(query);
            List<Holiday> list = new List<Holiday>();
            foreach (DataRow dr in dt.Rows)
            {
                list.Add(new Holiday()
                {
                    Id = Convert.ToInt32(dr["CoId"]),
                    Created = Convert.ToDateTime( dr["CoCreated"]),
                    Updated = Convert.ToDateTime(dr["CoUpdated"]),
                    Date = Convert.ToDateTime(dr["CoDate"]),
                    Reason = dr["CoReason"].ToString()
                });
            }
            return list;
        }

        
    }
}
