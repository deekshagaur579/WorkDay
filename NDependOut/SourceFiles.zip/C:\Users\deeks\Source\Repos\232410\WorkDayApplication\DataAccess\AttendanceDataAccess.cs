﻿using System;
using System.Collections.Generic;
using System.Data;
using WorkDayApplication.Models;
using WorkDayApplication.Utilities;

namespace WorkDayApplication.DataAccess
{
    public class AttendanceDataAccess
    {
        public List<Attendance> GetAttendanceDetails(string UserID)
        {
            string query = "Select CoId,CoUserID,CoAttendanceType,CoCreated,CoUpdated,CoStartTime,CoEndTime from TaAttendance Where CoUserID='"+ UserID + "'";
            DataTable dt = DataAccessUtility.ExecuteQuery(query);
            List<Attendance> list = new List<Attendance>();
            foreach (DataRow dr in dt.Rows)
            {
                list.Add(new Attendance()
                {
                    id = Convert.ToInt32(dr["CoId"]),
                    UserID = dr["CoUserID"].ToString(),
                    AttendanceType = dr["CoAttendanceType"].ToString(),
                    Created = Convert.ToDateTime( dr["CoCreated"]).Date,
                    Updated = Convert.ToDateTime(dr["CoUpdated"]),
                    StartTime = dr["CoStartTime"].ToString(),
                    EndTime = dr["CoEndTime"].ToString()
                });
            }
            return list;
        }

        
    }
}
