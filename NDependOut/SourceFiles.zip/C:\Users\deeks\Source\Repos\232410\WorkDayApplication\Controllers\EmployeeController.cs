﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WorkDayApplication.Interfaces;
using WorkDayApplication.Models;
using WorkDayApplication.ViewModels;

namespace WorkDayApplication.Controllers
{
    public class EmployeeController : Controller
    {
        // GET: EmployeeController
        public ActionResult EmployeeList()
        {
            UserViewModel emp = new UserViewModel();
            return View(emp.GetEmployeeList());
        }
        public ActionResult EmployeeDetails(string UserId)
        {
            UserViewModel empObj = new UserViewModel();
            User emp = new User();
            emp = empObj.GetEmployeeDetails(UserId);
            HttpContext.Session.SetString("UserId", emp.UserID);
            HttpContext.Session.SetString("Role", emp.Role.ToString());
            //Builder pattern
            if (emp.Role == Utilities.UserRole.Employee)
            {
                IUserBuilder employeeBuilder = new EmployeeBuilder();
                UserDirector employeeDirector = new UserDirector(employeeBuilder);

                User employee = employeeDirector.Construct(emp);
                return View(employee);
            }
            else
                if (emp.Role == Utilities.UserRole.Admin)
            {
                IUserBuilder adminBuilder = new AdminBuilder();
                UserDirector adminDirector = new UserDirector(adminBuilder);

                User admin = adminDirector.Construct(emp);
                return View(admin);
            }
            else
            {
                IUserBuilder teamLeaderBuilder = new TeamLeaderBuilder();
                UserDirector teamLeaderDirector = new UserDirector(teamLeaderBuilder);

                User teamLeader = teamLeaderDirector.Construct(emp);
                return View(teamLeader);
            }
            
        }


        public ActionResult EmployeeStatus(int id, bool status, string userId)
        {
            User employee = new User(userId, id, status);

            // Create commands for activating and deactivating the employee
            ICommand activateCommand = new ActivateUserCommand(employee);
            ICommand deactivateCommand = new DeactivateUserCommand(employee);

            // Create an invoker and add the commands
            UserCommandInvoker invoker = new UserCommandInvoker();
            invoker.AddCommand(activateCommand);
            invoker.AddCommand(deactivateCommand);

            // Execute the commands
            invoker.ExecuteCommands();
            return RedirectToAction("EmployeeList");
        }
    }
}


