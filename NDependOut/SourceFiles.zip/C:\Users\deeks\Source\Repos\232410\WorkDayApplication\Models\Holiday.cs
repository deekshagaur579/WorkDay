﻿using System;
using System.Collections.Generic;
using WorkDayApplication.DataAccess;
using WorkDayApplication.Utilities;

namespace WorkDayApplication.Models
{
    public class Holiday
    {
        public int Id { get; set; }
        public DateTime Created { get; set; }
        public DateTime Updated { get; set; }
        public DateTime Date { get; set; }
        public string Reason { get; set; }

    }

}
