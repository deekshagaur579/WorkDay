﻿using System;
using System.Collections.Generic;
using WorkDayApplication.DataAccess;
using WorkDayApplication.Utilities;

namespace WorkDayApplication.Models
{
    public class Attendance
    {
        public int id { get; set; }
        public string UserID { get; set; }
        public string AttendanceType { get; set; }
        public string StartTime { get; set; }
        public string EndTime { get; set; }
        public DateTime Created { get; set; }
        public DateTime Updated { get; set; }

    }

}
