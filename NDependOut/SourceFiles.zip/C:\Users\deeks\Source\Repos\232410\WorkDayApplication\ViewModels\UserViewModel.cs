﻿using System;
using System.Collections.Generic;
using System.Xml.Linq;
using WorkDayApplication.DataAccess;
using WorkDayApplication.Interfaces;
using WorkDayApplication.Models;
using WorkDayApplication.Utilities;

namespace WorkDayApplication.ViewModels
{
    // Product: User
    public class UserViewModel
    {
        public List<User> GetEmployeeList()
        {
            UserDataAccess EDA = new UserDataAccess();
            return EDA.GetEmployeeList();
        }

        public void ChangeStatus(int id, bool newValue)
        {
            UserDataAccess EDA = new UserDataAccess();
            EDA.ChangeEmployeeStatus(id, newValue);
        }

        public User GetEmployeeDetails(string userID)
        {
            UserDataAccess EDA = new UserDataAccess();
            return EDA.GetEmployeeDetails(userID);
        }
    }

    // Concrete Builder for Employee
    public class EmployeeBuilder : IUserBuilder
    {
        private User user = new User();
        public void SetId(int id){
            user.id = id;
        }
        public void SetUserID(string userID){
            user.UserID = userID;
        }
       public void SetFirstName(string firstName){
            user.FirstName = firstName;
        }
        public void SetLastName(string lastName){
           user.LastName = lastName;
        }
        public void SetCreated(DateTime created){
            user.Created = created;
        }
        public void SetUpdated(DateTime updated){
            user.Updated = updated;
        }
        public void SetRole(UserRole role){
            user.Role = role;
        }
        public void SetAddress(string addressLine1, string addressLine2, string addressLine3){
            user.AddressLine1 = addressLine1;
            user.AddressLine2 = addressLine2;
            user.AddressLine3 = addressLine3;
        }
        public void SetDesignation(string designation){
            user.Designation = designation;
        }
        public void SetDepartment(string department){
            user.Department = department;
        }
        //public void SetActive(Boolean active){
        //    user.Active = active;
        //}

        public User Build()
        {
            return user;
        }
    }

    // Concrete Builder for Admin
    public class AdminBuilder : IUserBuilder
    {
        private User user = new User();
        public void SetId(int id)
        {
            user.id = id;
        }
        public void SetUserID(string userID)
        {
            user.UserID = userID;
        }
        public void SetFirstName(string firstName)
        {
            user.FirstName = firstName;
        }
        public void SetLastName(string lastName)
        {
            user.LastName = lastName;
        }
        public void SetCreated(DateTime created)
        {
            user.Created = created;
        }
        public void SetUpdated(DateTime updated)
        {
            user.Updated = updated;
        }
        public void SetRole(UserRole role)
        {
            user.Role = role;
        }
        public void SetAddress(string addressLine1, string addressLine2, string addressLine3)
        {
            user.AddressLine1 = addressLine1;
            user.AddressLine2 = addressLine2;
            user.AddressLine3 = addressLine3;
        }
        public void SetDesignation(string designation)
        {
            user.Designation = designation;
        }
        public void SetDepartment(string department)
        {
            user.Department = department;
        }
        //public void SetActive(Boolean active)
        //{
        //    user.Active = active;
        //}

        public User Build()
        {
            return user;
        }
    }

    // Concrete Builder for Team Leader
    public class TeamLeaderBuilder : IUserBuilder
    {
        private User user = new User();
        public void SetId(int id)
        {
            user.id = id;
        }
        public void SetUserID(string userID)
        {
            user.UserID = userID;
        }
        public void SetFirstName(string firstName)
        {
            user.FirstName = firstName;
        }
        public void SetLastName(string lastName)
        {
            user.LastName = lastName;
        }
        public void SetCreated(DateTime created)
        {
            user.Created = created;
        }
        public void SetUpdated(DateTime updated)
        {
            user.Updated = updated;
        }
        public void SetRole(UserRole role)
        {
            user.Role = role;
        }
        public void SetAddress(string addressLine1, string addressLine2, string addressLine3)
        {
            user.AddressLine1 = addressLine1;
            user.AddressLine2 = addressLine2;
            user.AddressLine3 = addressLine3;
        }
        public void SetDesignation(string designation)
        {
            user.Designation = designation;
        }
        public void SetDepartment(string department)
        {
            user.Department = department;
        }
        //public void SetActive(Boolean active)
        //{
        //    user.Active = active;
        //}

        public User Build()
        {
            return user;
        }
    }

    // Director
    public class UserDirector
    {
        private IUserBuilder userBuilder;

        public UserDirector(IUserBuilder builder)
        {
            userBuilder = builder;
        }

        public User Construct(User emp)
        {
            userBuilder.SetId(emp.id);
            userBuilder.SetUserID(emp.UserID);
            userBuilder.SetFirstName(emp.FirstName);
            userBuilder.SetLastName(emp.LastName);
            userBuilder.SetCreated(emp.Created);
            userBuilder.SetUpdated(emp.Updated);
            userBuilder.SetRole(emp.Role);
            userBuilder.SetAddress(emp.AddressLine1, emp.AddressLine2, emp.AddressLine3);
            userBuilder.SetDesignation(emp.Designation);
            userBuilder.SetDepartment(emp.Department);
            //userBuilder.SetActive(emp.Active);
            return userBuilder.Build();
        }
    }

    // Invoker class command pattern
    public class UserCommandInvoker//put in user model : comment
    {
        private readonly List<ICommand> commands = new List<ICommand>();

        public void AddCommand(ICommand command)
        {
            commands.Add(command);
        }

        public void ExecuteCommands()
        {
            foreach (var command in commands)
            {
                command.Execute();
            }

            commands.Clear();
        }
    }
    // Concrete command for activating an employee
    public class ActivateUserCommand : ICommand
    {
        private readonly User user;

        public ActivateUserCommand(User user)
        {
            this.user = user;
        }

        public void Execute()
        {
            user.Activate();
        }
    }

    // Concrete command for deactivating an employee
    public class DeactivateUserCommand : ICommand
    {
        private readonly User user;
        public DeactivateUserCommand(User user)
        {
            this.user = user;
        }
        public void Execute()
        {
            user.Deactivate();
        }
    }
}