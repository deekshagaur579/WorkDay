﻿using System;
using WorkDayApplication.Utilities;
using WorkDayApplication.ViewModels;

namespace WorkDayApplication.Models
{
    // Product: User
    // Receiver class : command pattern
    public class User
    {
        public int id { get; set; }
        public string UserID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime Created { get; set; }
        public DateTime Updated { get; set; }
        public UserRole Role { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string AddressLine3 { get; set; }
        public string Designation { get; set; }
        public string Department { get; set; }
        public Boolean Active { get; set; }
        public string Name { get; }
        public bool IsActive { get; private set; }

        public User() { }
        public User(string userId, int Id,bool status)
        {
            id = Id;
            UserID = userId;
            IsActive = status;
        }
        public void Activate()
        {
            if (IsActive == true)
            {
                UserViewModel emp = new UserViewModel();
                emp.ChangeStatus(id, IsActive);
            }
        }

        public void Deactivate()
        {
            if (IsActive == false)
            {
                UserViewModel emp = new UserViewModel();
                emp.ChangeStatus(id, IsActive);
            }
        }

    }

}



