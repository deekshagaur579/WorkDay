﻿namespace WorkDayApplication.Utilities
{
    public enum LeaveStatus
    {
        None,
        Applied,
        Cancelled,
        Aprooved
    };
    public enum UserRole { 
        Employee,
        Admin,
        TeamLeader
    }
}
