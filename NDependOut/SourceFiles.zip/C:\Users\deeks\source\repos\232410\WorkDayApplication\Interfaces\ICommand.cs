﻿namespace WorkDayApplication.Interfaces
{
    // Command interface
    public interface ICommand
    {
        void Execute();
    }
}
