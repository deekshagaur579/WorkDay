﻿//using WorkDayEntityModel;
//using System.Linq;
//using System.Collections.Generic;
//using static Microsoft.EntityFrameworkCore.DbLoggerCategory;
using System;
using System.ComponentModel.DataAnnotations;
using WorkDayApplication.DataAccess;
using WorkDayApplication.Models;

namespace WorkDayApplication.Models
{
    //SingletonClass
    public class Login
    {
        [Required]
        //[Display(Name = "Username")]
        public string UserID { get; set; }

        [Required]
        //[DataType(DataType.Password)]
        public string Password { get; set; }
        public string Role { get; set; }

        private static Login _instance;
        private readonly LoginDataAccess _loginDataAccess;

        public Login()
        {
            _loginDataAccess = new LoginDataAccess();
        }
        public static Login Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new Login();
                }
                return _instance;
            }
        }
        public bool ValidateLogin(string userid, string password)
        {
            string dbPassword = _loginDataAccess.ValidatePassword(userid);

            if (dbPassword == password)
            {
                return true;
            }

            return false;
        }
    }
}
