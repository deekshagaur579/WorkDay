﻿using System;
using System.Collections.Generic;
using System.Data;
using WorkDayApplication.Models;
using WorkDayApplication.Utilities;

namespace WorkDayApplication.DataAccess
{
    public class LeaveDataAccess
    {
        public List<LeaveAccount> GetLeaveAccount(string CoUserID)
        {
            string query = "Select CoId,CoUserId,CoLeaveType,CoYear,CoCreated,CoUpdated,CoOpening,CoCredited,CoAvailed,CoApplied,coApproved,CoBalance from TaAccountLeave where CoUserID = " + CoUserID;
            DataTable dt = DataAccessUtility.ExecuteQuery(query);
            List<LeaveAccount> list = new List<LeaveAccount>();
            foreach (DataRow dr in dt.Rows)
            {
                list.Add(new LeaveAccount()
                {
                    Id = Convert.ToInt32(dr["CoId"]),
                    UserID = dr["CoUserId"].ToString(),
                    LeaveType = dr["CoLeaveType"].ToString(),
                    Year = Convert.ToInt32(dr["CoYear"]),
                    Opening = Convert.ToInt32(dr["CoOpening"]),
                    Credited = Convert.ToInt32(dr["CoCredited"]),
                    Availed = Convert.ToInt32(dr["CoAvailed"]),
                    Applied = Convert.ToInt32(dr["CoApplied"]),
                    Approved = Convert.ToInt32(dr["coApproved"]),
                    Balance = Convert.ToInt32(dr["CoBalance"])
                });
            }
            return list;
        }
        public LeaveAccount GetLeaveAccountById(int LeaveId)
        {
            string query = "Select CoId,CoUserId,CoLeaveType,CoYear,CoCreated,CoUpdated,CoOpening,CoCredited,CoAvailed,CoApplied,coApproved,CoBalance from TaAccountLeave where CoId = " + LeaveId;
            DataRow dr = DataAccessUtility.ExecuteQuery(query).Rows[0];
            LeaveAccount x = new LeaveAccount();
            x.Id = Convert.ToInt32(dr["CoId"]);
            x.UserID = dr["CoUserId"].ToString();
            x.LeaveType = dr["CoLeaveType"].ToString();
            x.Year = Convert.ToInt32(dr["CoYear"]);
            x.Opening = Convert.ToInt32(dr["CoOpening"]);
            x.Credited = Convert.ToInt32(dr["CoCredited"]);
            x.Availed = Convert.ToInt32(dr["CoAvailed"]);
            x.Applied = Convert.ToInt32(dr["CoApplied"]);
            x.Approved = Convert.ToInt32(dr["coApproved"]);
            x.Balance = Convert.ToInt32(dr["CoBalance"]);
            return x;
        }
        public void SaveLeave(Leave leave)
        {
                string query = @"insert into TaLeave(
                                CoLeaveAccountId,
                                CoStartdate,
                                CoEndDate,
                                CoApplydate,
                                coReason,
                                CoStatus)
                                values(" + leave.Id
                                             + "," + (leave.Startdate == null ? "GETDATE()" : leave.Startdate.ToString())
                                             + "," + (leave.EndDate == null ? "GETDATE()" : leave.EndDate.ToString())
                                             + "," + (leave.Applydate == null ? "GETDATE()" : leave.Applydate.ToString())
                                             + ",'" + leave.Reason
                                             + "','" + leave.Status.ToString()
                                             + "'  ) ";
                DataAccessUtility.Update(query);
        }
        public void UpdateLeaves(Leave leave)
        {
            string query = "Update TaAccountLeave set CoApplied = {0} ,CoBalance = {1},coApproved = {2} ,CoAvailed ={3} where CoId = " + leave.Id;
            decimal? Applied = 0, Availed = 0, Balance = 0, Aprooved = 0;
            if (leave.Status == LeaveStatus.Applied)
            {
                Applied = leave.leaveAccount.Applied + 1;
                Balance = leave.leaveAccount.Balance - 1;
            }
            else if (leave.Status == LeaveStatus.Aprooved)
            {
                Aprooved = leave.leaveAccount.Approved + 1;
                Availed = leave.leaveAccount.Availed + 1;
                Applied = leave.leaveAccount.Applied - 1;
            }
            else if (leave.Status == LeaveStatus.Cancelled)
            {
                Applied = leave.leaveAccount.Applied - 1;
                Balance = leave.leaveAccount.Balance + 1;
            }
            query = string.Format(query, Applied, Balance, Aprooved, Availed);
            DataAccessUtility.Update(query);
        }
    }
}
