﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using WorkDayApplication.Models;
using WorkDayApplication.ViewModels;

namespace WorkDayApplication.Controllers
{
    public class HolidayController : Controller
    {
        public ActionResult HolidayDetails()
        {
            HolidayViewModel obj = new HolidayViewModel();
            List<Holiday> listData = new List<Holiday>();
            listData = obj.GetHolidayList();
            return View(listData);
        }
    }
}
