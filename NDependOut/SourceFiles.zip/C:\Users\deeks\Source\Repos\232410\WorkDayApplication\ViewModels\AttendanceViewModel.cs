﻿using System;
using System.Collections.Generic;
using WorkDayApplication.DataAccess;
using WorkDayApplication.Interfaces;
using WorkDayApplication.Models;
using WorkDayApplication.Utilities;

namespace WorkDayApplication.ViewModels
{
    // Concrete Component
    public class AttendanceViewModel : IAttendance
    {
        public List<Attendance> GetAttendance(string userID)
        {
            AttendanceDataAccess ADA = new AttendanceDataAccess();
            return ADA.GetAttendanceDetails(userID);
        }
    }

    // Decorator
    abstract class AttendanceDecorator : IAttendance
    {
        protected IAttendance _attendance;

        public AttendanceDecorator(IAttendance attendance)
        {
            _attendance = attendance;
        }

        public virtual List<Attendance> GetAttendance(string employeeId)
        {
            return _attendance.GetAttendance(employeeId);
        }
    }
  
}
